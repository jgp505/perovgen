import os
import sys

from perovgen.pygmd import *

__author__ = "Green Materials Design Lab"
__maintainer__ = "Park Jong Goo"
__email__ = "jgp505@gmail.com"
__version__ = "3.5.1"
__date__ = "2021-06-03"

# auto_process & argument revised